var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { AnnotationBody } from "./internal";
/**
An implementation of the TextualBody class (class in JSON-LD sense)
as it is described in Web Annotation Data Model Section 3.2.4
https://www.w3.org/TR/annotation-model/#embedded-textual-body
**/
var TextualBody = /** @class */ (function (_super) {
    __extends(TextualBody, _super);
    function TextualBody(jsonld, options) {
        var _this = _super.call(this, jsonld, options) || this;
        _this.isModel = false;
        _this.isLight = false;
        _this.isCamera = false;
        return _this;
    }
    Object.defineProperty(TextualBody.prototype, "isTextualBody", {
        /**
        identify an instance of this typescript as representing a resource
        having these json-ld Class relationships.
        **/
        get: function () { return true; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(TextualBody.prototype, "isText", {
        get: function () { return true; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(TextualBody.prototype, "Value", {
        /**
        The simple string that is the data content of this resource
        will return empty string as a default value
        **/
        get: function () { return this.getProperty("value") || ""; },
        enumerable: false,
        configurable: true
    });
    return TextualBody;
}(AnnotationBody));
export { TextualBody };
//# sourceMappingURL=TextualBody.js.map